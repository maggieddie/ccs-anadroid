package org.ucombinator.dalvik.cfa.cesk


/*
 *  more statics needed. 
 */

case class CFAStatistics 
(timeSec: Long,
 //numExp: Int,
 //numVars: Int, thsi one might not be available
 //numSingletons: Int,
 numStates: Int,
 numEdges: Int,
 interrupted: Boolean)