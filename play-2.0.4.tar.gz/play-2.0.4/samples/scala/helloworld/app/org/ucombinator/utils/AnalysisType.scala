package org.ucombinator.utils

object AnalysisType extends Enumeration {
  type AnalysisType = Value
  val PDCFA, KCFA = Value
}