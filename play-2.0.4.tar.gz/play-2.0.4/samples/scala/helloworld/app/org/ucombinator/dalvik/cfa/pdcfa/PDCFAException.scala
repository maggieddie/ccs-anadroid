package org.ucombinator.dalvik.cfa.pdcfa

class PDCFAException(msg: String)  extends Exception(msg){

}