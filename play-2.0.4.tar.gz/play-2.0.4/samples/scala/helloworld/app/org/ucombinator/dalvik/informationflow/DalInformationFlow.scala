package org.ucombinator.dalvik.informationflow
import scala.tools.nsc.io.File
import org.ucombinator.utils.StringUtils


/**
 * maintaining the source and sinks strings, as well as sensitive string values
 * 
 * The source and sink files is separated for the sake of clarity
 * 
 * The taint propagation rules are in StackCESKMachinary
 */
object DalInformationFlow { 
  
    val taintKinds = Set("sdcard",
    				     "filesystem",
    				     "picture",
    				     "network", 
    				     "location",
    				     "sms",
    				     "phone",
    				     "tobedetermined",
    				     "voice",
    				     "display","executable", "timeordate", 
    				     "reflection", "deviceid",   "browserbosokmark", 
    				     "browserhistory", "thread")  
 
	var sources: Set[(String, String)] = Set[(String, String)]()
	var sinks: Set[(String, String)] = Set[(String, String)]()

	// contains complete files names, (like /sdcard)
	// http://, .cc
	var sensitiveStrings: Set[(String, String)] = Set[(String, String)]()

	def decideTaintKinds(name: String) : Set[String] = {
	  val kindsFromSources = sources.foldLeft(Set[String]())((res: Set[String], p) => {
	    val str = p._1
	    val kind = p._2
	    if (str == name)  
	          res + kind 
	          else res
	  })
	   val kindsFromSinks = sinks.foldLeft(Set[String]())((res: Set[String], p) => {
	    val str = p._1
	    val kind = p._2
	    if (str == name)  
	          res + kind 
	          else res
	  })
	  
	  val res = kindsFromSources ++ kindsFromSinks
	 
	  res 
	}
	
	def isSensitiveStr(input: String) : Boolean = {
	 
	  val individuals =  sensitiveStrings.filter((recStr) => {
	    
	    input.contains(recStr._1)
	  })
	  val strSs = sensitiveStrings.map(_._1)
	  val cond1 = strSs.contains(input) 
	  val cond2 = !individuals.isEmpty 
	  
	  cond1 || cond2
	 
	}
	
	def getTaintKindsForString(input: String) : Set[String] = {
	    val kindsFromSs = sensitiveStrings.foldLeft(Set[String]())((res: Set[String], p) => {
	    val str = p._1
	    val kind = p._2
	    if (input.contains(str))  
	          res + kind 
	          else res
	  })
	 
	  kindsFromSs
	}
	
	def decideSourceOrSinkLevel(name: String): Int = {
	 // println("sdfsfgsdlkhfjksdgjshkdadfsjdklssfkjdla;a")
	  val strsSources = sources.map(_._1)
	  val inSource = strsSources.contains(name)
	  val individualSrcs =  sources.filter((src) => {
	    val name2 = StringUtils.getMethNameFromMethPath(name)
	    name2.contains(src._1)
	  })
	  val srcCond2 =  !individualSrcs.isEmpty 
	  
	  val strsSinks = sinks.map(_._1)
	  val inSink  = strsSinks.contains(name)
	  
	  val individualSinkss =  sinks.filter((src) => {
	   val name2 = StringUtils.getMethNameFromMethPath(name)
	    name2.contains(src._1)
	  })
	  val sinkCond2 =  !individualSinkss.isEmpty 
	 
	  
	  val isSrc = (inSource || srcCond2)  
	  val isSink =  (inSink || sinkCond2)
	  
	  if(isSrc && isSink) 3
	  else if(isSrc == true && isSink == false) 1
	  else if(isSrc == false && isSink == true) 2
	  else 0
	}
	
	 def parseInAndroidKnowledge   {
		val srcPath  =  "android-knowledge" + File.separator + "sources.txt"
		val sinkPath = "android-knowledge" + File.separator + "sinks.txt" 
		val sstringPath = "android-knowledge" + File.separator + "sensitive-strings.txt"
		
		val sourcesLines =  File(srcPath).lines.toList.filter(_ != "")
		sources =  sourcesLines.map((ps)=>{
		  val pairStr = ps.split("\\ ").toList
		  (pairStr(0), pairStr(1))
		  
		}).toSet  //sourcesLines.toSet 
		 
		val sinkLines = File(sinkPath).lines.toList.filter(_ != "")
	    sinks = sinkLines.map((ps)=>{
		  val pairStr = ps.split("\\ ").toList
		  (pairStr(0), pairStr(1))
		  
		}).toSet 
	    
	    val ssLines = File(sstringPath).lines.toList.filter(_ != "")
	    sensitiveStrings = ssLines.map((ps)=>{
		  val pairStr = ps.split("\\ ").toList
		  (pairStr(0), pairStr(1))
		  
		}).toSet
	}
}