package controllers

import play.api._
import play.api.mvc._
import play.api.data._
import play.api.data.Forms._
import play.api.Play.current
import views._
import java.io.File
import play.api.libs.json._

object Application extends Controller {

  /**
   * Describes the hello form.
   */
  val helloForm = Form(
    tuple(
      "name" -> nonEmptyText,
      "repeat" -> number(min = 1, max = 100),
      "color" -> optional(text)
    )
  )
  
  val configForm = Form(
      tuple(
          "k" -> optional(number),
          "gc" -> optional(text),
          "stateCutoff" -> number(min = 1),
          "verbose" -> optional(text) 
          )
      )

  // -- Actions

  /**
   * Home page
   */
  def index = Action {
    Ok(html.index(helloForm))
  }
  
  private def getFileName(fn: String) : String = {
    val splitted = fn.split("\\.").toList
    if(!splitted.isEmpty){
      splitted.head
    }else
      fn
  }

  /**
   * Handles the form submission.
   */
  def sayHello = Action { implicit request =>
    helloForm.bindFromRequest.fold(
      formWithErrors => BadRequest(html.index(formWithErrors)),
      {case (name, repeat, color) => Ok(html.hello(name, repeat.toInt, color))}
    )
  }

  // uploadFile -> configure
  def uploadFile = Action(parse.multipartFormData) { implicit request =>
    request.body.file("apkfile").map { picture =>
      import java.io.File
      val filename = picture.filename
      println(filename)
      
      val contentType = picture.contentType
      println(contentType)
      // want to build separate project file folder
      val path = "/tmp" + File.separator + 
      // random
      "1" +  File.separator + getFileName(filename)
      val pathfolder = new File(path)
      val pathfolderD = pathfolder.mkdir()
     
     
      val newpath = path + File.separator + filename
      picture.ref.moveTo(new File(newpath))
      // when the updaload is OK, we want to direct to the configure page
      
      Ok(html.configure(configForm, newpath))
      
    }.getOrElse {
      Redirect(routes.Application.index).flashing(
        "error" -> "Missing file")
    }
}
  
  case class FileInfo(path: String, info: String)
  
  private def jsonResult() : JsValue = {
    
    Json.toJson(
    Seq(Json.toJson(
        Map("link"->Json.toJson("/assets/apks/2.svg"),  "type" -> Json.toJson("SVG")) 
        ),
        Json.toJson(
        Map("link"->Json.toJson("/assets/apks/index.html"),  "type" -> Json.toJson("HTML")) 
        ),
        Json.toJson(
         Map("link"->Json.toJson("/assets/apks/1.svg"),  "type" -> Json.toJson("SVG Not Ready")) 
         )
        )
        )
  }
  // config knows the apks folder
  // it will pass to the result displaying
  def config(path: String) = Action { implicit request =>
    configForm.bindFromRequest.fold(
      formWithErrors => BadRequest("form format errors"),
      {case (k, gc, stateCutoff, verbose) => 
        Ok(html.simple(jsonResult()))
            //Play.application.path.getPath()) //html.simple())// "k= " + k + " gc=" + gc + " stateCutoff " + 
            // stateCutoff + path)
          
      }
    )
  }
  
}
