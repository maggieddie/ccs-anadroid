/** Automatically generated file. DO NOT MODIFY */
package com.todo.todo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}