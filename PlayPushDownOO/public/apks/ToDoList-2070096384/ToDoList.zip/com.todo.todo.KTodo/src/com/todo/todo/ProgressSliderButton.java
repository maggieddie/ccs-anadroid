package com.todo.todo;


/**
 * Todo add javadoc
 *
 * @author <a href="mailto:ksobolev@linkedin.com" title="">Konstantin Sobolev</a>
 */
public class ProgressSliderButton {
}
