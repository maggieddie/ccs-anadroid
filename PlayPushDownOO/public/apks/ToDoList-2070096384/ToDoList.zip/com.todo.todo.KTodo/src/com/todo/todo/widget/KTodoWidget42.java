package com.todo.todo.widget;

public class KTodoWidget42 extends KTodoWidgetBase {
}