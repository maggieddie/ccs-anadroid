package com.todo.todo.widget;

public class KTodoWidget24 extends KTodoWidgetBase {
}