package com.todo.todo;

public enum DueStatus {
	NONE, EXPIRED, TODAY, FUTURE
}
