package com.todo.todo;

import com.todo.todo.R;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.preference.PreferenceManager;
import android.text.TextPaint;
import android.util.AttributeSet;
import android.widget.CheckedTextView;

public class TodoItemView extends CheckedTextView {
	private static final String[] PRIO_TO_STRING = new String[]{"0", "1", "2", "3", "4", "5"};

	private String prio;
	private boolean showNotesMark;

	private Drawable checkmark;

	private String dueDate;
	private Float dueDateWidth;
	private DueStatus dueStatus;

	private int paddingRightPx;
	private int checkMarkWidthPx;
	private int minHeight;

	private final float prioFontSizePx;
	private final float notesPrioMarginRightPx;
	private final float prioMarginTopPx;
	private final float notesDueMarginBottomPx;
	private final float dueFontSizePx;
	private final float dueMarginRightPx;

	private final TodoItemBackgroundDrawable tcd;
	private final Drawable notesDrawable;
	private final int dueDateColor, todayDueDateColor, expiredDueDateColor;
	private final int[] prioToColor;

	public TodoItemView(final Context context, final AttributeSet attrs) {
		super(context, attrs);

		final SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);

		final TypedArray ta_tiv = context.obtainStyledAttributes(attrs, R.styleable.TodoItemView);
		final TypedArray ta_prio = context.obtainStyledAttributes(attrs, R.styleable.PrioColor);

		final int prio1Color = prefs.getInt("prio1Color", ta_prio.getColor(R.styleable.PrioColor_prio1Color, context.getResources().getColor(R.color.prio_1)));
		final int prio2Color = prefs.getInt("prio2Color", ta_prio.getColor(R.styleable.PrioColor_prio2Color, context.getResources().getColor(R.color.prio_2)));
		final int prio3Color = prefs.getInt("prio3Color", ta_prio.getColor(R.styleable.PrioColor_prio3Color, context.getResources().getColor(R.color.prio_3)));
		final int prio4Color = prefs.getInt("prio4Color", ta_prio.getColor(R.styleable.PrioColor_prio4Color, context.getResources().getColor(R.color.prio_4)));
		final int prio5Color = prefs.getInt("prio5Color", ta_prio.getColor(R.styleable.PrioColor_prio5Color, context.getResources().getColor(R.color.prio_5)));


		final int c1 = ta_tiv.getColor(R.styleable.TodoItemView_progress0Color, Color.BLACK);
		final int c2 = prefs.getInt("progressColor", ta_tiv.getColor(R.styleable.TodoItemView_progress100Color, Color.GRAY));
		dueDateColor = prefs.getInt("dueDateColor", ta_tiv.getColor(R.styleable.TodoItemView_dueDateColor, Color.WHITE));
		todayDueDateColor = prefs.getInt("dueTodayColor", ta_tiv.getColor(R.styleable.TodoItemView_todayDueDateColor, Color.YELLOW));
		expiredDueDateColor = prefs.getInt("overdueColor", ta_tiv.getColor(R.styleable.TodoItemView_expiredDueDateColor, Color.RED));

		prioToColor = new int[]{
				ta_prio.getColor(R.styleable.PrioColor_prio0Color, context.getResources().getColor(R.color.prio_0)),
				prio1Color,
				prio2Color,
				prio3Color,
				prio4Color,
				prio5Color,
		};

		final int prioStripeWidthPx = (int) ta_tiv.getDimension(R.styleable.TodoItemView_prioStripeWidth, 0.0f);
		tcd = new TodoItemBackgroundDrawable(c1, c2, prioStripeWidthPx);
		notesDrawable = ta_tiv.getDrawable(R.styleable.TodoItemView_notesDrawable);

		prioFontSizePx = ta_tiv.getDimension(R.styleable.TodoItemView_prioFontSize, 0.0f);
		dueFontSizePx = ta_tiv.getDimension(R.styleable.TodoItemView_dueFontSize, 0.0f);
		notesPrioMarginRightPx = ta_tiv.getDimension(R.styleable.TodoItemView_notesPrioMarginRight, 0.0f);
		notesDueMarginBottomPx = ta_tiv.getDimension(R.styleable.TodoItemView_notesDueMarginBottom, 0.0f);
		prioMarginTopPx = ta_tiv.getDimension(R.styleable.TodoItemView_prioMarginTop, 0.0f);
		dueMarginRightPx = ta_tiv.getDimension(R.styleable.TodoItemView_dueMarginRight, 0.0f);


		ta_tiv.recycle();
		ta_prio.recycle();

		setBackgroundDrawable(tcd);
	}

	public void setPrio(final int prio) {
		this.prio = PRIO_TO_STRING[prio];
		if (!isChecked())
			tcd.setPrioColor(prioToColor[prio]);
		else
			tcd.setPrioColor(prioToColor[0]);
	}

	public void setProgress(final int progress) {
		tcd.setPercent(progress);
	}

	public void setShowNotesMark(final boolean showNotesMark) {
		this.showNotesMark = showNotesMark;
	}

	public void setDueDate(final String dueDate, final DueStatus dueStatus) {
		this.dueDate = dueDate;
		this.dueStatus = dueStatus;
		dueDateWidth = null;
		updateSuperCheckmark();
	}

	@Override
	public void setPadding(final int left, final int top, final int right, final int bottom) {
		super.setPadding(left, top, right, bottom);
		paddingRightPx = right;
	}

	@Override
	public void setCheckMarkDrawable(final Drawable d) {
		checkmark = d;
		checkMarkWidthPx = d != null ? d.getIntrinsicWidth() : 0;
		updateSuperCheckmark();
	}

	public int getCheckMarkWidthPx() {
		return checkMarkWidthPx;
	}

	private void updateSuperCheckmark() {
		if (checkmark == null)
			return;

		float acc = notesPrioMarginRightPx;
		if (notesDrawable != null)
			acc += notesDrawable.getIntrinsicWidth();

		if (dueDate != null)
			acc += getDueDateWidth() + dueMarginRightPx;

		final int checkmarkWidthExtra = (int) acc;

		// pretend checkmark drawable is wider by checkmarkWidthExtra
		// to accomodate more space for prio, notes mark and due date
		super.setCheckMarkDrawable(new DelegatingDrawable(checkmark) {
			@Override
			public int getIntrinsicWidth() {
				return checkmark.getIntrinsicWidth() + checkmarkWidthExtra;
			}

			@Override
			public void setBounds(int left, int top, int right, int bottom) {
				super.setBounds(left + checkmarkWidthExtra, top, right, bottom);
			}
		});
	}

	private float getDueDateWidth() {
		if (dueDateWidth != null)
			return dueDateWidth;
		if (dueDate == null)
			return 0.0f;

		final TextPaint p = new TextPaint(getPaint());
		p.setTextSize(dueFontSizePx);
		dueDateWidth = p.measureText(dueDate);
		return dueDateWidth;
	}

	@Override
	public void setSelected(final boolean selected) {
		super.setSelected(selected);
		updateBackground();
	}

	@Override
	public void setPressed(final boolean pressed) {
		super.setPressed(pressed);
		updateBackground();
	}

	private void updateBackground() {
		if (isSelected() || isPressed())
			setBackgroundDrawable(null);
		else
			setBackgroundDrawable(tcd);
	}

	@Override
	public void setMinHeight(final int minHeight) {
		//this allows to workaround the fact that setCheckmarkDrawable sets min heigh to 72 (check mark height)
		//essentially we make the value set in constructor (and thus obtained from xml) to be the final one
		if (this.minHeight == 0) {
			this.minHeight = minHeight;
			super.setMinHeight(minHeight);
		}
	}

	@Override
	protected void onDraw(final Canvas canvas) {
		super.onDraw(canvas);

		final Paint p = new Paint(getPaint());
		p.setTextSize(prioFontSizePx);

		final float prioWidthPx = p.measureText(prio);
		final Rect bounds = new Rect();
		p.getTextBounds(prio, 0, prio.length(), bounds);
		final float prioHeightPx = bounds.height();

		final float widthMinusCheckmarkPadding = getWidth() - checkMarkWidthPx - paddingRightPx;
		final float prioX = widthMinusCheckmarkPadding - prioWidthPx - notesPrioMarginRightPx + prioWidthPx / 2;
		float notesX = prioX;
		float halfNotesHeightPx = 0;

		canvas.drawText(prio, prioX, prioMarginTopPx + prioHeightPx, p);

		if (notesDrawable != null) {
			final int notesHeightPx = notesDrawable.getIntrinsicHeight();
			final int notesWidthPx = notesDrawable.getIntrinsicWidth();
			halfNotesHeightPx = notesHeightPx / 2;
			notesX = widthMinusCheckmarkPadding - notesWidthPx - notesPrioMarginRightPx + notesWidthPx / 2;
			if (showNotesMark) {
				notesDrawable.setBounds((int) notesX, (int) (getHeight() - notesHeightPx - notesDueMarginBottomPx),
						(int) (notesX + notesWidthPx), (int) (getHeight() - notesDueMarginBottomPx));
				notesDrawable.draw(canvas);
			}
		}
		if (dueDate != null) {
			p.setTextSize(dueFontSizePx);

			int color = dueDateColor;
			if (!isChecked()) {
				if (dueStatus == DueStatus.TODAY)
					color = todayDueDateColor;
				else if (dueStatus == DueStatus.EXPIRED)
					color = expiredDueDateColor;
			}

			p.setColor(color);

			float notesCentering = 0;
			if (halfNotesHeightPx != 0) {
				p.getTextBounds(dueDate, 0, dueDate.length(), bounds);
				notesCentering = halfNotesHeightPx - (bounds.height() + 0.5f) / 2;
			}
			canvas.drawText(dueDate, notesX - getDueDateWidth() - dueMarginRightPx, getHeight() - notesDueMarginBottomPx - notesCentering, p);
		}
	}
}
