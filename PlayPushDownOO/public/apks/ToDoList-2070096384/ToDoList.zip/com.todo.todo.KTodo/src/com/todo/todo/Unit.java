package com.todo.todo;

/**
 * Poor man's Unit type
 */
public class Unit {
	public static final Unit u = new Unit();

	private Unit() {}
}
