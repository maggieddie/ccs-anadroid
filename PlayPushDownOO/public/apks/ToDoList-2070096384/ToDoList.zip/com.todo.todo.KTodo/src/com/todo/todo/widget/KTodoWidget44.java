package com.todo.todo.widget;

public class KTodoWidget44 extends KTodoWidgetBase {
}