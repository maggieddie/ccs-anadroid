package com.todo.todo.widget;

public class KTodoWidget22 extends KTodoWidgetBase {
}